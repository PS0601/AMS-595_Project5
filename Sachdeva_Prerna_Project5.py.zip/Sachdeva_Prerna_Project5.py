#QUESTION:1

print("---------------------------Question:1--------------------------------")
print("Question:1")
import numpy as np
from scipy.linalg import eig
#page rank matrix
M = np.array([
    [0.0, 0.0, 1/2, 0.0],
    [1/3, 0.0, 0.0, 1/2],
    [1/3, 1/2, 0.0, 1/2],
    [1/3, 1/2, 1/2, 0.0]
])
#computing eigen values and eigen vectors
values, vectors = eig(M)
#finding the index of the eigen value
idx = np.argmax(values.real)
v_eig = vectors[:, idx].real
#normalizing so ranks sums to 1
v_eig_normalized = v_eig / v_eig.sum()
print("Part 1 (eigenvector):", v_eig_normalized)

#rank vector of all ones
num_pages = M.shape[0]
v = np.ones(num_pages)
#normalizing the intial vector
v = v / v.sum()
#convergence parameters
tolerance = 1e-8
max_iterations = 1000
#iterating untill convergence
for step in range(max_iterations):
    v_next = M @ v
    v_next = v_next / v_next.sum()
    diff = np.linalg.norm(v_next - v, 1)
    if diff < tolerance:
        break
    v = v_next
print("Part 2 (power iteration):", v)

#normalizing again eigen vectors
v_eig_normalized = v_eig / v_eig.sum()
print("Part 3 (normalized eigenvector):", v_eig_normalized)
print("Sum of all ranks:", v_eig_normalized.sum())
print("Each entry is the long-run probability of being on that page.")

#finding the index of page with highest pagerank
highest_page_index = np.argmax(v_eig_normalized)
print("Part 4 (highest ranked page):", highest_page_index + 1)
print("This page has the highest PageRank because it has the largest long-run probability.")



print("---------------------------Question:2--------------------------------")

#QUESTION:2
print("Question:2")
from scipy.linalg import eigh
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
#loading the data
data = pd.read_csv("data.csv")
#extracting the matrix 
X = data[["Height", "Weight"]].values
#computing eigenvalues
cov_matrix = np.cov(X, rowvar=False)
print("Part 1 :Covariance matrix:")
print(cov_matrix)
#compute eigen values and vvectors of the covariance matrix
eigenvalues, eigenvectors = eigh(cov_matrix)
#sort in desc order
idx = np.argsort(eigenvalues)[::-1]
eigenvalues = eigenvalues[idx]
eigenvectors = eigenvectors[:, idx]
print("\nPart 2:Eigenvalues:")
print(eigenvalues)
print("Part 2:Eigenvectors (cols are principal directions):")
print(eigenvectors)
#computing the variance explained ratio
total_variance = eigenvalues.sum()
variance_ratio = eigenvalues / total_variance
print("Principal components :")
print(eigenvectors)
print("\nPart 3 : Variance explained by each principal component:")
print(variance_ratio)
print("The first principal component explains the most variance in height and weight.")
#select first pc1
pc1 = eigenvectors[:, 0]
#converting data to pc1 to 1d representation
X_1d = X @ pc1
#convert 1d projection back into 2d space 
X_projected = np.outer(X_1d, pc1)
print("\nPart 4 :First few 1D projections:")
print(X_1d[:10])
#plotting original 2D and 1D projection 
plt.figure()
plt.scatter(X[:, 0], X[:, 1], alpha=0.6, label="Original data")
plt.scatter(X_projected[:, 0], X_projected[:, 1], alpha=0.6, label="1D projection on PC1")
plt.xlabel("Height")
plt.ylabel("Weight")
plt.legend()
plt.title("Original data and 1D PCA projection")
plt.show()


print("---------------------------Question:3--------------------------------")
#QUESTION:3

print("Question:3")
import numpy as np
from scipy.linalg import lstsq
#data sqaure footage,bedrooms,age
X = np.array([
    [2100, 3, 20],
    [2500, 4, 15],
    [1800, 2, 30],
    [2200, 3, 25]
])
#house prices
y = np.array([460, 540, 330, 400])
print("Part 1 - X:")
print(X)
print("Part 1 - y:")
print(y)
#find the best fit coefficients that minimizes the error 
beta, residuals, rank, s = lstsq(X, y)
print("Part 2 - beta (coefficients):")
print(beta)
# house: 400 squareft,3 bedrooms, 20 years old
new_house = np.array([2400, 3, 20])
predicted_price = new_house @ beta
print("Part 3 - Predicted price:", predicted_price)
#predicted values
y_pred = X @ beta
print("Least-squares predicted values:", y_pred)
#residuals error
print("Residual sum of squares:", residuals)
#trying direct solve 
from scipy.linalg import solve

try:
    solve(X, y)
except Exception as e:
    print("Direct solve failed:", e)
#comparing the performance 
print("The least-squares method finds the best-fitting coefficients by minimizing the squared error between the predicted prices and the actual prices. It performs well when the system is over-determined and noisy. A direct method like scipy.linalg.solve requires a perfectly square matrix and would not handle noise or imperfect relationships well. " \
"Least-squares is more stable, gives the optimal fit, and works even when the system does not have an exact solution.")

print("---------------------------Question:4--------------------------------")
#QUESTION:4
print("Question:4")
import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt
#setting matrix dimensions
m, n = 100, 50
np.random.seed(0)
#initialize A(target matrix) and X0 initial guess) with random values
A = np.random.randn(m, n)
X0 = np.random.randn(m, n)
#flatten X0 into a 1D vector 
X_flat0 = X0.ravel()

def loss_func(X_flat):
    #reshape flat vector back into m*n matrix
    X = X_flat.reshape(m, n)
    #diff between x and target matrix A
    diff = X - A
    return 0.5 * np.sum(diff * diff)
def grad_func(X_flat):
    #reshape flat vector back into m*n matrix
    X = X_flat.reshape(m, n)
    #gradient =X-A(target)
    grad = X - A
    #return gradient
    return grad.ravel()
#list that stores the loss values 
loss_history = []
#lost last x if we stop early
last_X = None
#to stop gradient descent when convergence is reached
class StopGD(Exception):
    pass

def callback_func(X_flat):
    global last_X
    #save current x
    last_X = X_flat.copy()
    #compute current loss
    value = loss_func(X_flat)
    #store loss in history
    loss_history.append(value)
    #if loss more than two then find there difference 
    if len(loss_history) > 1:
        #if loss chnage is small no optimization
        if abs(loss_history[-1] - loss_history[-2]) < 1e-6:
            raise StopGD

try:
    result = minimize(
        fun=loss_func,#loss function
        x0=X_flat0,
        jac=grad_func,#gradient of  loss
        method="CG",
        callback=callback_func,
        options={"maxiter": 1000}
    )
    X_opt_flat = result.x
except StopGD:
    #if manually stopped then use the last x that came from callback
    X_opt_flat = last_X
#reshape optimized flat vector 
X_opt = X_opt_flat.reshape(m, n)
plt.plot(loss_history)
plt.xlabel("Iteration")
plt.ylabel("Loss")
plt.title("Loss over iterations")
plt.show()
#print final lossvalue and no of iterations
print("Final loss:", loss_history[-1])
print("Iterations:", len(loss_history))
